import unittest
from app import create_app, db
from models import User, Tenant
from werkzeug.security import generate_password_hash
from config import TestingConfig

class TestAuthentication(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = create_app()
        cls.app.config.from_object(TestingConfig)
        cls.app_context = cls.app.app_context()
        cls.app_context.push()
        db.create_all()
        cls.client = cls.app.test_client()
        # Create test tenant and user
        tenant = Tenant(name="Test Company", company_email="test@company.com", company_phone="+30123456789", primary_color="#1ba3a3", secondary_color="#ffffff")
        db.session.add(tenant)
        db.session.flush()
        user = User(tenant_id=tenant.id, username="testuser", email="test@example.com", password_hash=generate_password_hash("testpassword"), role="admin", is_active=True)
        db.session.add(user)
        db.session.commit()
        cls.test_user_id = user.id
        cls.tenant_id = tenant.id

    @classmethod
    def tearDownClass(cls):
        db.session.remove()
        db.drop_all()
        cls.app_context.pop()

    def test_login(self):
        response = self.client.post('/auth/login', data={
            'username': 'testuser',
            'password': 'testpassword'
        }, follow_redirects=True)
        self.assertEqual(response.status_code, 200)

    def test_password_security(self):
        user = User.query.filter_by(username='testuser').first()
        self.assertTrue(user.password_hash.startswith('pbkdf2:sha256'))

    def test_unauthorized_access(self):
        response = self.client.get('/dashboard', follow_redirects=True)
        self.assertIn(b'Please log in', response.data)

    def test_sql_injection_prevention(self):
        # This is a stub. Implement a real SQL injection test if needed.
        response = self.client.post('/auth/login', data={
            'username': "' OR 1=1; --",
            'password': 'irrelevant'
        }, follow_redirects=True)
        self.assertIn(b'Invalid username or password', response.data)

if __name__ == "__main__":
    unittest.main() 