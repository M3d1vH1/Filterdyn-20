import unittest
from app import create_app, db
from models import User, Tenant
from werkzeug.security import generate_password_hash
from config import TestingConfig

class TestInternationalization(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = create_app()
        cls.app.config.from_object(TestingConfig)
        cls.app_context = cls.app.app_context()
        cls.app_context.push()
        db.create_all()
        tenant = Tenant(name="Test Company", company_email="test@company.com", company_phone="+30123456789", primary_color="#1ba3a3", secondary_color="#ffffff")
        db.session.add(tenant)
        db.session.flush()
        user = User(tenant_id=tenant.id, username="testuser", email="test@example.com", password_hash=generate_password_hash("testpassword"), role="admin", is_active=True)
        db.session.add(user)
        db.session.commit()
        cls.tenant_id = tenant.id
        cls.user_id = user.id

    @classmethod
    def tearDownClass(cls):
        db.session.remove()
        db.drop_all()
        cls.app_context.pop()

    def test_language_switching(self):
        with self.app.test_client() as client:
            with client.session_transaction() as sess:
                sess['language'] = 'el'  # Greek
            response = client.get('/dashboard')
            # Stub: Check for Greek content in response
            self.assertEqual(response.status_code, 200)
            # self.assertIn(b'Καλωσήρθατε', response.data)  # Example Greek string

    def test_default_language(self):
        with self.app.test_client() as client:
            response = client.get('/dashboard')
            self.assertEqual(response.status_code, 200)
            # self.assertIn(b'Welcome', response.data)  # Example English string

if __name__ == "__main__":
    unittest.main() 