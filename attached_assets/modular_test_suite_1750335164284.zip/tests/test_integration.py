import unittest
from app import create_app, db
from models import User, Tenant, Customer, Quote
from werkzeug.security import generate_password_hash
from config import TestingConfig

class TestIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = create_app()
        cls.app.config.from_object(TestingConfig)
        cls.app_context = cls.app.app_context()
        cls.app_context.push()
        db.create_all()
        tenant = Tenant(name="Test Company", company_email="test@company.com", company_phone="+30123456789", primary_color="#1ba3a3", secondary_color="#ffffff")
        db.session.add(tenant)
        db.session.flush()
        user = User(tenant_id=tenant.id, username="testuser", email="test@example.com", password_hash=generate_password_hash("testpassword"), role="admin", is_active=True)
        db.session.add(user)
        db.session.commit()
        cls.tenant_id = tenant.id
        cls.user_id = user.id

    @classmethod
    def tearDownClass(cls):
        db.session.remove()
        db.drop_all()
        cls.app_context.pop()

    def test_login_create_customer_and_quote(self):
        with self.app.test_client() as client:
            # Login
            response = client.post('/auth/login', data={
                'username': 'testuser',
                'password': 'testpassword'
            }, follow_redirects=True)
            self.assertEqual(response.status_code, 200)
            # Create customer
            response = client.post('/customers/create', data={
                'name': 'Integration Customer',
                'email': 'integration@customer.com',
                'contact_person': 'Integration Person'
            }, follow_redirects=True)
            self.assertEqual(response.status_code, 200)
            customer = Customer.query.filter_by(name='Integration Customer').first()
            self.assertIsNotNone(customer)
            # Create quote (stub, as actual fields may vary)
            quote = Quote(tenant_id=self.tenant_id, customer_id=customer.id, created_by=self.user_id, status="draft")
            db.session.add(quote)
            db.session.commit()
            self.assertIsNotNone(quote.id)

if __name__ == "__main__":
    unittest.main() 