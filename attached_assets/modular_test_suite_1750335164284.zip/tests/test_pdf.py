import unittest
from app import create_app, db
from models import User, Tenant, Quote
from werkzeug.security import generate_password_hash
from config import TestingConfig
# Assume pdf_generator has a function generate_pdf(quote_id)
try:
    from pdf_generator import generate_pdf
except ImportError:
    generate_pdf = None

class TestPDFGeneration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = create_app()
        cls.app.config.from_object(TestingConfig)
        cls.app_context = cls.app.app_context()
        cls.app_context.push()
        db.create_all()
        # Create test tenant, user, and quote
        tenant = Tenant(name="Test Company", company_email="test@company.com", company_phone="+30123456789", primary_color="#1ba3a3", secondary_color="#ffffff")
        db.session.add(tenant)
        db.session.flush()
        user = User(tenant_id=tenant.id, username="testuser", email="test@example.com", password_hash=generate_password_hash("testpassword"), role="admin", is_active=True)
        db.session.add(user)
        db.session.flush()
        quote = Quote(tenant_id=tenant.id, customer_id=1, created_by=user.id, status="draft")
        db.session.add(quote)
        db.session.commit()
        cls.quote_id = quote.id

    @classmethod
    def tearDownClass(cls):
        db.session.remove()
        db.drop_all()
        cls.app_context.pop()

    def test_generate_pdf(self):
        if generate_pdf is None:
            self.skipTest("PDF generation function not available")
        try:
            pdf_bytes = generate_pdf(self.quote_id)
            self.assertIsNotNone(pdf_bytes)
        except Exception as e:
            self.fail(f"PDF generation failed: {e}")

if __name__ == "__main__":
    unittest.main() 