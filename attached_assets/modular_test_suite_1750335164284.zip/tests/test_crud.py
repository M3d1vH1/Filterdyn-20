import unittest
from app import create_app, db
from models import User, Tenant, Customer, Product, Quote, Order, Task
from werkzeug.security import generate_password_hash
from config import TestingConfig

class TestCRUD(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = create_app()
        cls.app.config.from_object(TestingConfig)
        cls.app_context = cls.app.app_context()
        cls.app_context.push()
        db.create_all()
        cls.client = cls.app.test_client()
        # Create test tenant and user
        tenant = Tenant(name="Test Company", company_email="test@company.com", company_phone="+30123456789", primary_color="#1ba3a3", secondary_color="#ffffff")
        db.session.add(tenant)
        db.session.flush()
        user = User(tenant_id=tenant.id, username="testuser", email="test@example.com", password_hash=generate_password_hash("testpassword"), role="admin", is_active=True)
        db.session.add(user)
        db.session.commit()
        cls.tenant_id = tenant.id
        cls.user_id = user.id

    @classmethod
    def tearDownClass(cls):
        db.session.remove()
        db.drop_all()
        cls.app_context.pop()

    def test_customer_crud(self):
        # Create
        customer = Customer(tenant_id=self.tenant_id, name="CRUD Customer", email="crud@customer.com", phone="+3000000000", contact_person="CRUD Person")
        db.session.add(customer)
        db.session.commit()
        # Read
        found = Customer.query.filter_by(name="CRUD Customer").first()
        self.assertIsNotNone(found)
        # Update
        found.name = "CRUD Customer Updated"
        db.session.commit()
        updated = Customer.query.filter_by(name="CRUD Customer Updated").first()
        self.assertIsNotNone(updated)
        # Delete
        db.session.delete(updated)
        db.session.commit()
        deleted = Customer.query.filter_by(name="CRUD Customer Updated").first()
        self.assertIsNone(deleted)

    def test_product_crud(self):
        # Stub: Implement product CRUD
        self.assertTrue(True)

    def test_quote_crud(self):
        # Stub: Implement quote CRUD
        self.assertTrue(True)

    def test_order_crud(self):
        # Stub: Implement order CRUD
        self.assertTrue(True)

    def test_task_crud(self):
        # Stub: Implement task CRUD
        self.assertTrue(True)

if __name__ == "__main__":
    unittest.main() 