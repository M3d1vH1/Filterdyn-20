# Modular Test Suite for Replit

This project includes a modularized test suite located in the `tests/` directory. Each major area of the application is covered by its own test file, making it easy to run, debug, and extend tests on Replit or any other environment.

## How to Run All Tests

You can run all tests using:

```
python -m unittest discover tests
```

Or use the Replit "Run" button if configured to do so.

## Test Coverage

- `test_auth.py` — Authentication & security
- `test_crud.py` — CRUD for all main models
- `test_pdf.py` — PDF generation
- `test_i18n.py` — Internationalization
- `test_performance.py` — Performance (page load)
- `test_usability.py` — Usability (page loads, form validation)
- `test_error_handling.py` — Error handling (404, 500)
- `test_integration.py` — End-to-end integration flow

Each test file:
- Sets up its own app and database context
- Cleans up after itself
- Can be run independently or as part of the full suite

For more details, see the code in the `tests/` directory. 